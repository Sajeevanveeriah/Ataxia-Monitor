Rev B LTspice verification. Raw waveforms are regenerable and omitted.
Use scripts/verify_touch.py for simultaneous and --interaction suites.
The source hashes identify the exact C++ and simulation code used.
For reference/reference.cir, download https://www.ti.com/lit/zip/sbom241 and place REF3325.LIB beside the circuit. The TI model is not redistributed.
The 10 uA contact criterion is frequency-weighted. Raw contact pulses exceed 10 uA. See the Rev01 design note.
